﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PFW.CSIST203.Project1.Functions
{

    public class ArrayFunctions
    {

        /// <summary>
        /// The persistent file used to load and store data when the Store() and Load() methods are utilized
        /// </summary>
        /// <returns></returns>
        internal string PersistentFile { get; set; }

        public static readonly string DefaultPersistentFile = "data.txt";

        internal Random Randomizer { get; set; }

        public ArrayFunctions() : this("data.txt")
        {
        }

        public ArrayFunctions(string persistentFile) : this(persistentFile, null)
        {
        }
        /// <summary>
        /// get the full path of the directory and check if the file exists or is null
        /// </summary>
        /// <param name="persistentFile"></param>
        /// <param name="seed"></param>
        public ArrayFunctions(string persistentFile, int? seed)
        {
            if (string.IsNullOrWhiteSpace(persistentFile))
                throw new ArgumentException();
            var fullPath = System.IO.Path.GetFullPath(persistentFile);
            var dir = System.IO.Path.GetDirectoryName(fullPath);

            if (!System.IO.Directory.Exists(dir)) 
                throw new System.IO.DirectoryNotFoundException();


            PersistentFile = persistentFile;
            if (null == seed)
            {
                this.Randomizer = new Random();

            }
            else
            { this.Randomizer = new Random(seed.Value); }
        }

        /// <summary>
        /// Write the Array to the PersistentFile 
        /// </summary>
        /// <param name="data"></param>
        public void Store(string[] data)
        {

            if (string.IsNullOrWhiteSpace(data.ToString()))
                throw new ArgumentException();
            var fullPath = System.IO.Path.GetFullPath(data.ToString());
            var dir = System.IO.Path.GetDirectoryName(fullPath);

            if (!System.IO.Directory.Exists(dir))
                throw new System.IO.DirectoryNotFoundException();


            PersistentFile = data.ToString();
            if (null == data)
            {
                this.Randomizer = new Random();

            }
            else
            { this.Randomizer = new Random(data.Length); }


            //Join the array together 
            string content = string.Join(System.Environment.NewLine, data);
            //Save the file to disk
            System.IO.File.WriteAllText(PersistentFile, content);


        }

        /// <summary>
        /// Load the array from the persistent file 
        /// </summary>
        /// <param name="dataCount"></param>
        /// <returns>Stored Array</returns>
        public string[] Load(int dataCount)
        {
            var data = string.Empty;
            try
            {
                //Join the array together 
                string content = string.Join(System.Environment.NewLine, data);
                
                string[] newArray = new string[dataCount];
                string[] read = System.IO.File.ReadAllLines(PersistentFile);
                // data = System.IO.File.ReadAllText(PersistentFile);
                char[] splitchar = { ' ' };
                string[] lines = new string[read.Length] ; 

                for (int i = 0 ; i < read.Length; i++) 
                {
                    lines[i] = read[i];//Split(splitchar);
                }
                return lines;

            }
            catch (System.IO.FileNotFoundException fnf)
            {
                throw fnf;
            }
            catch (System.Exception ex)
            {
                throw ex;

            }



        }

        /// <summary>
        /// Randomize the Array using the internal Randomizer 
        /// </summary>
        /// <param name="data"></param>
        /// <returns>Random Array</returns>
        public string[] Randomize(string[] data)
        {
            return data.OrderBy(n => this.Randomizer.Next()).ToArray();
        }

        /// <summary>
        /// Create a New Array and Copy the index 
        /// move the last element to the first index and the rest of the elements to the index to the left of itself
        /// </summary>
        /// <param name="data"></param>
        /// <returns>newArray</returns>
        public string[] ShiftRight(string[] data)
        {
            //create new Array
            string[] newArray = new string[data.Length];
            //retrieve the first element of the input Array 
            var item1 = data[0];
            //copy index  1..n into 0..n-1
            for (int i = 1; i < data.Length; i++)
            {
                newArray[i] = data[i -1];
            }

            //copy the first element into the new arrays last element
            newArray[0] = data[newArray.Length - 1];
            //return the new Array
            return newArray;


        }

        /// <summary>
        /// Create a New Array and Copy the index 
        /// move the first element to the last index and the rest of the elements to the index to the left of itself
        /// </summary>
        /// <param name="data"></param>
        /// <returns>newArray</returns>
        public string[] ShiftLeft(string[] data)
        {
            //create new Array
            string[] newArray = new string[data.Length];
            //retrieve the first element of the input Array 
            var item1 = data[0];
            //copy index  1..n into 0..n-1
            for (int i = 1; i < data.Length; i++) 
            {
                newArray[i - 1] = data[i];            
            }

            //copy the first element into the new arrays last element
            newArray[data.Length - 1] = item1;
            //return the new Array
            return newArray;
        }

        /// <summary>
        /// Create a New Array and Copy the index 
        /// move the first element to the last index and the rest of the elements to the index + 1
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public string[] Reverse(string[] data)
        {
            //create new Array 
            string[] newArray= new string[data.Length];
            //retrieve the first element of the input Array
            var item1 = data[0];
            // Copy the index of the Array
            for (int i = 0; i < data.Length; i++)
            {    
                newArray[i] = data[data.Length - (i + 1)];
            }
            return newArray;
        }
    }

}
