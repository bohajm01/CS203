﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PFW.CSIST203.Project1.Functions
{
    public class MathFunctions
    {
        private log4net.ILog logger = log4net.LogManager.GetLogger(typeof(MathFunctions));
        internal static readonly string ErrorMessage = "Error";
        /// <summary>
        /// Shared Add Method
        /// </summary>
        /// <param name="input1"></param>
        /// <param name="input2"></param>
        /// <returns>Addition Result</returns>
        public string Add(string input1, string input2)
        {
            // Parse out decimal values for both inputs
 
            if (decimal.TryParse(input1, out decimal val1) &&
                decimal.TryParse(input2, out decimal val2))
            {
                // Add them together 
                decimal result = val1 + val2;

                // Return the results as a String
                return result.ToString();
            }
            return ErrorMessage; 
        }

        /// <summary>
        /// Shared Subtraction Method
        /// </summary>
        /// <param name="input1"></param>
        /// <param name="input2"></param>
        /// <returns>Subtraction Result</returns>
        public string Subtract(string input1, string input2)
        {
 
            // Parse out decimal values for both inputs
        
            if (decimal.TryParse(input1, out decimal val1) &&
                decimal.TryParse(input2, out decimal val2))
            {
                // Subtract them 
                decimal result = val1 - val2;

                // Return the results as a String
                return result.ToString();
            }
            return ErrorMessage;
        }

        /// <summary>
        /// Shared Times Method
        /// </summary>
        /// <param name="input1"></param>
        /// <param name="input2"></param>
        /// <returns>Multiplication result </returns>
        public string Multiply(string input1, string input2)
        {
            // Parse out decimal values for both inputs
    
            if (decimal.TryParse(input1, out decimal val1) &&
                decimal.TryParse(input2, out decimal val2))
            {
                // Multiply them together 
                decimal result = val1 * val2;

                // Return the results as a String
                return result.ToString();
            }
            return ErrorMessage;
        }
        /// <summary>
        /// Shared Division Method
        /// </summary>
        /// <param name="input1"></param>
        /// <param name="input2"></param>
        /// <returns>Division Result</returns>
        public string Divide(string input1, string input2)
        {
            // Parse out double values for both inputs

            if (decimal.TryParse(input1, out decimal val1) &&
                decimal.TryParse(input2, out decimal val2) && val2 != 0)
            {
                // Divide them
                decimal result = val1 / val2;

                // Return the results as a String
                return result.ToString();
            }
            return ErrorMessage;
        }

        /// <summary>
        /// Shared Modulus Result
        /// </summary>
        /// <param name="input1"></param>
        /// <param name="input2"></param>
        /// <returns>Modulus result</returns>
        public string Modulus(string input1, string input2)
        {
            // Parse out decimal values for both inputs

            if (decimal.TryParse(input1, out decimal val1) &&
                decimal.TryParse(input2, out decimal val2) && val2 != 0)
            {
                // Find the remainder
                decimal result = val1 % val2;

                // Return the results as a String
                return result.ToString();
            }
            return ErrorMessage;
        }
        /// <summary>
        /// Shared Exponent Method
        /// </summary>
        /// <param name="input1"></param>
        /// <param name="input2"></param>
        /// <returns>Exponent results</returns>
        public string Power(string input1, string input2)
        {
            // Parse out double values for both inputs

            if (double.TryParse(input1, out double val1) &&
                double.TryParse(input2, out double val2))

            {

                //check for 0 fromo val1 and val2 
                if (val1 == 0 && val2 < 0)
                {
                    return ErrorMessage;
                }
                else 
                {
                    double result = 1;
                    double i;
                    for (i = 0; i < val2; i++)
                    {
                        result = Math.Pow(val1, val2);
                       // result = result *= val1; //Return the results as a String
                    }  
                         return result.ToString();
                }
            }
            return ErrorMessage;
        }

    }

}
