﻿namespace PFW.CSIST203.Project1
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GroupBox2 = new System.Windows.Forms.GroupBox();
            this.Label4 = new System.Windows.Forms.Label();
            this.txtArray1 = new System.Windows.Forms.TextBox();
            this.btnReverse = new System.Windows.Forms.Button();
            this.txtArray2 = new System.Windows.Forms.TextBox();
            this.btnShiftLeft = new System.Windows.Forms.Button();
            this.txtArray3 = new System.Windows.Forms.TextBox();
            this.btnShiftRight = new System.Windows.Forms.Button();
            this.txtArray4 = new System.Windows.Forms.TextBox();
            this.btnRandomize = new System.Windows.Forms.Button();
            this.txtArray5 = new System.Windows.Forms.TextBox();
            this.btnLoad = new System.Windows.Forms.Button();
            this.Label5 = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.Label6 = new System.Windows.Forms.Label();
            this.Label8 = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.lblOperator = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.txtValue1 = new System.Windows.Forms.TextBox();
            this.txtValue2 = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.txtResultant = new System.Windows.Forms.TextBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnSubtract = new System.Windows.Forms.Button();
            this.btnMultiply = new System.Windows.Forms.Button();
            this.btnDivide = new System.Windows.Forms.Button();
            this.btnModulus = new System.Windows.Forms.Button();
            this.btnPower = new System.Windows.Forms.Button();
            this.GroupBox2.SuspendLayout();
            this.GroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // GroupBox2
            // 
            this.GroupBox2.Controls.Add(this.Label4);
            this.GroupBox2.Controls.Add(this.txtArray1);
            this.GroupBox2.Controls.Add(this.btnReverse);
            this.GroupBox2.Controls.Add(this.txtArray2);
            this.GroupBox2.Controls.Add(this.btnShiftLeft);
            this.GroupBox2.Controls.Add(this.txtArray3);
            this.GroupBox2.Controls.Add(this.btnShiftRight);
            this.GroupBox2.Controls.Add(this.txtArray4);
            this.GroupBox2.Controls.Add(this.btnRandomize);
            this.GroupBox2.Controls.Add(this.txtArray5);
            this.GroupBox2.Controls.Add(this.btnLoad);
            this.GroupBox2.Controls.Add(this.Label5);
            this.GroupBox2.Controls.Add(this.btnSave);
            this.GroupBox2.Controls.Add(this.Label6);
            this.GroupBox2.Controls.Add(this.Label8);
            this.GroupBox2.Controls.Add(this.Label7);
            this.GroupBox2.Location = new System.Drawing.Point(43, 293);
            this.GroupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.GroupBox2.Name = "GroupBox2";
            this.GroupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.GroupBox2.Size = new System.Drawing.Size(804, 241);
            this.GroupBox2.TabIndex = 31;
            this.GroupBox2.TabStop = false;
            this.GroupBox2.Text = "Array Functions";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Location = new System.Drawing.Point(60, 60);
            this.Label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(50, 17);
            this.Label4.TabIndex = 17;
            this.Label4.Text = "Data 1";
            // 
            // txtArray1
            // 
            this.txtArray1.Location = new System.Drawing.Point(60, 100);
            this.txtArray1.Margin = new System.Windows.Forms.Padding(4);
            this.txtArray1.Name = "txtArray1";
            this.txtArray1.Size = new System.Drawing.Size(132, 22);
            this.txtArray1.TabIndex = 12;
            this.txtArray1.Text = "first";
            // 
            // btnReverse
            // 
            this.btnReverse.Location = new System.Drawing.Point(603, 149);
            this.btnReverse.Margin = new System.Windows.Forms.Padding(4);
            this.btnReverse.Name = "btnReverse";
            this.btnReverse.Size = new System.Drawing.Size(100, 28);
            this.btnReverse.TabIndex = 27;
            this.btnReverse.Text = "Reverse";
            this.btnReverse.UseVisualStyleBackColor = true;
            this.btnReverse.Click += new System.EventHandler(this.BtnReverse_Click);
            // 
            // txtArray2
            // 
            this.txtArray2.Location = new System.Drawing.Point(201, 100);
            this.txtArray2.Margin = new System.Windows.Forms.Padding(4);
            this.txtArray2.Name = "txtArray2";
            this.txtArray2.Size = new System.Drawing.Size(132, 22);
            this.txtArray2.TabIndex = 13;
            this.txtArray2.Text = "second";
            // 
            // btnShiftLeft
            // 
            this.btnShiftLeft.Location = new System.Drawing.Point(493, 149);
            this.btnShiftLeft.Margin = new System.Windows.Forms.Padding(4);
            this.btnShiftLeft.Name = "btnShiftLeft";
            this.btnShiftLeft.Size = new System.Drawing.Size(100, 28);
            this.btnShiftLeft.TabIndex = 26;
            this.btnShiftLeft.Text = "Shift Left";
            this.btnShiftLeft.UseVisualStyleBackColor = true;
            this.btnShiftLeft.Click += new System.EventHandler(this.BtnShiftLeft_Click);
            // 
            // txtArray3
            // 
            this.txtArray3.Location = new System.Drawing.Point(344, 98);
            this.txtArray3.Margin = new System.Windows.Forms.Padding(4);
            this.txtArray3.Name = "txtArray3";
            this.txtArray3.Size = new System.Drawing.Size(132, 22);
            this.txtArray3.TabIndex = 14;
            this.txtArray3.Text = "third";
            // 
            // btnShiftRight
            // 
            this.btnShiftRight.Location = new System.Drawing.Point(384, 149);
            this.btnShiftRight.Margin = new System.Windows.Forms.Padding(4);
            this.btnShiftRight.Name = "btnShiftRight";
            this.btnShiftRight.Size = new System.Drawing.Size(100, 28);
            this.btnShiftRight.TabIndex = 25;
            this.btnShiftRight.Text = "Shift Right";
            this.btnShiftRight.UseVisualStyleBackColor = true;
            this.btnShiftRight.Click += new System.EventHandler(this.BtnShiftRight_Click);
            // 
            // txtArray4
            // 
            this.txtArray4.Location = new System.Drawing.Point(493, 98);
            this.txtArray4.Margin = new System.Windows.Forms.Padding(4);
            this.txtArray4.Name = "txtArray4";
            this.txtArray4.Size = new System.Drawing.Size(132, 22);
            this.txtArray4.TabIndex = 15;
            this.txtArray4.Text = "fourth";
            // 
            // btnRandomize
            // 
            this.btnRandomize.Location = new System.Drawing.Point(276, 149);
            this.btnRandomize.Margin = new System.Windows.Forms.Padding(4);
            this.btnRandomize.Name = "btnRandomize";
            this.btnRandomize.Size = new System.Drawing.Size(100, 28);
            this.btnRandomize.TabIndex = 24;
            this.btnRandomize.Text = "Randomize";
            this.btnRandomize.UseVisualStyleBackColor = true;
            this.btnRandomize.Click += new System.EventHandler(this.BtnRandomize_Click);
            // 
            // txtArray5
            // 
            this.txtArray5.Location = new System.Drawing.Point(636, 98);
            this.txtArray5.Margin = new System.Windows.Forms.Padding(4);
            this.txtArray5.Name = "txtArray5";
            this.txtArray5.Size = new System.Drawing.Size(132, 22);
            this.txtArray5.TabIndex = 16;
            this.txtArray5.Text = "fifth";
            // 
            // btnLoad
            // 
            this.btnLoad.Location = new System.Drawing.Point(169, 149);
            this.btnLoad.Margin = new System.Windows.Forms.Padding(4);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(100, 28);
            this.btnLoad.TabIndex = 23;
            this.btnLoad.Text = "Load";
            this.btnLoad.UseVisualStyleBackColor = true;
            this.btnLoad.Click += new System.EventHandler(this.BtnLoad_Click);
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Location = new System.Drawing.Point(197, 60);
            this.Label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(50, 17);
            this.Label5.TabIndex = 18;
            this.Label5.Text = "Data 2";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(60, 149);
            this.btnSave.Margin = new System.Windows.Forms.Padding(4);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(100, 28);
            this.btnSave.TabIndex = 22;
            this.btnSave.Text = "Store";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.BtnSave_Click);
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Location = new System.Drawing.Point(340, 60);
            this.Label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(50, 17);
            this.Label6.TabIndex = 19;
            this.Label6.Text = "Data 3";
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Location = new System.Drawing.Point(632, 60);
            this.Label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(50, 17);
            this.Label8.TabIndex = 21;
            this.Label8.Text = "Data 5";
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Location = new System.Drawing.Point(489, 60);
            this.Label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(50, 17);
            this.Label7.TabIndex = 20;
            this.Label7.Text = "Data 4";
            // 
            // GroupBox1
            // 
            this.GroupBox1.Controls.Add(this.lblOperator);
            this.GroupBox1.Controls.Add(this.Label1);
            this.GroupBox1.Controls.Add(this.txtValue1);
            this.GroupBox1.Controls.Add(this.txtValue2);
            this.GroupBox1.Controls.Add(this.Label2);
            this.GroupBox1.Controls.Add(this.txtResultant);
            this.GroupBox1.Controls.Add(this.Label3);
            this.GroupBox1.Controls.Add(this.btnAdd);
            this.GroupBox1.Controls.Add(this.btnSubtract);
            this.GroupBox1.Controls.Add(this.btnMultiply);
            this.GroupBox1.Controls.Add(this.btnDivide);
            this.GroupBox1.Controls.Add(this.btnModulus);
            this.GroupBox1.Controls.Add(this.btnPower);
            this.GroupBox1.Location = new System.Drawing.Point(43, 28);
            this.GroupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.GroupBox1.Size = new System.Drawing.Size(804, 242);
            this.GroupBox1.TabIndex = 30;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "Mathematical Functions";
            // 
            // lblOperator
            // 
            this.lblOperator.AutoSize = true;
            this.lblOperator.Location = new System.Drawing.Point(272, 80);
            this.lblOperator.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblOperator.Name = "lblOperator";
            this.lblOperator.Size = new System.Drawing.Size(16, 17);
            this.lblOperator.TabIndex = 12;
            this.lblOperator.Text = "+";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(72, 53);
            this.Label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(56, 17);
            this.Label1.TabIndex = 2;
            this.Label1.Text = "Value 1";
            // 
            // txtValue1
            // 
            this.txtValue1.Location = new System.Drawing.Point(72, 76);
            this.txtValue1.Margin = new System.Windows.Forms.Padding(4);
            this.txtValue1.Name = "txtValue1";
            this.txtValue1.Size = new System.Drawing.Size(168, 22);
            this.txtValue1.TabIndex = 0;
            this.txtValue1.Text = "0";
            // 
            // txtValue2
            // 
            this.txtValue2.Location = new System.Drawing.Point(319, 76);
            this.txtValue2.Margin = new System.Windows.Forms.Padding(4);
            this.txtValue2.Name = "txtValue2";
            this.txtValue2.Size = new System.Drawing.Size(167, 22);
            this.txtValue2.TabIndex = 1;
            this.txtValue2.Text = "0";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(319, 52);
            this.Label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(56, 17);
            this.Label2.TabIndex = 3;
            this.Label2.Text = "Value 2";
            // 
            // txtResultant
            // 
            this.txtResultant.Enabled = false;
            this.txtResultant.Location = new System.Drawing.Point(580, 76);
            this.txtResultant.Margin = new System.Windows.Forms.Padding(4);
            this.txtResultant.Name = "txtResultant";
            this.txtResultant.Size = new System.Drawing.Size(132, 22);
            this.txtResultant.TabIndex = 4;
            this.txtResultant.Text = "0";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(576, 52);
            this.Label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(68, 17);
            this.Label3.TabIndex = 5;
            this.Label3.Text = "Resultant";
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(72, 175);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(4);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(100, 28);
            this.btnAdd.TabIndex = 6;
            this.btnAdd.Text = "+";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.BtnAdd_Click);
            // 
            // btnSubtract
            // 
            this.btnSubtract.Location = new System.Drawing.Point(180, 175);
            this.btnSubtract.Margin = new System.Windows.Forms.Padding(4);
            this.btnSubtract.Name = "btnSubtract";
            this.btnSubtract.Size = new System.Drawing.Size(100, 28);
            this.btnSubtract.TabIndex = 7;
            this.btnSubtract.Text = "-";
            this.btnSubtract.UseVisualStyleBackColor = true;
            this.btnSubtract.Click += new System.EventHandler(this.BtnSubtract_Click);
            // 
            // btnMultiply
            // 
            this.btnMultiply.Location = new System.Drawing.Point(288, 175);
            this.btnMultiply.Margin = new System.Windows.Forms.Padding(4);
            this.btnMultiply.Name = "btnMultiply";
            this.btnMultiply.Size = new System.Drawing.Size(100, 28);
            this.btnMultiply.TabIndex = 8;
            this.btnMultiply.Text = "*";
            this.btnMultiply.UseVisualStyleBackColor = true;
            this.btnMultiply.Click += new System.EventHandler(this.BtnMultiply_Click);
            // 
            // btnDivide
            // 
            this.btnDivide.Location = new System.Drawing.Point(396, 175);
            this.btnDivide.Margin = new System.Windows.Forms.Padding(4);
            this.btnDivide.Name = "btnDivide";
            this.btnDivide.Size = new System.Drawing.Size(100, 28);
            this.btnDivide.TabIndex = 9;
            this.btnDivide.Text = "/";
            this.btnDivide.UseVisualStyleBackColor = true;
            this.btnDivide.Click += new System.EventHandler(this.BtnDivide_Click);
            // 
            // btnModulus
            // 
            this.btnModulus.Location = new System.Drawing.Point(505, 175);
            this.btnModulus.Margin = new System.Windows.Forms.Padding(4);
            this.btnModulus.Name = "btnModulus";
            this.btnModulus.Size = new System.Drawing.Size(100, 28);
            this.btnModulus.TabIndex = 10;
            this.btnModulus.Text = "%";
            this.btnModulus.UseVisualStyleBackColor = true;
            this.btnModulus.Click += new System.EventHandler(this.BtnModulus_Click);
            // 
            // btnPower
            // 
            this.btnPower.Location = new System.Drawing.Point(615, 175);
            this.btnPower.Margin = new System.Windows.Forms.Padding(4);
            this.btnPower.Name = "btnPower";
            this.btnPower.Size = new System.Drawing.Size(100, 28);
            this.btnPower.TabIndex = 11;
            this.btnPower.Text = "^";
            this.btnPower.UseVisualStyleBackColor = true;
            this.btnPower.Click += new System.EventHandler(this.BtnPower_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(889, 561);
            this.Controls.Add(this.GroupBox2);
            this.Controls.Add(this.GroupBox1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CS203/IST203 Project #1";
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.GroupBox2.ResumeLayout(false);
            this.GroupBox2.PerformLayout();
            this.GroupBox1.ResumeLayout(false);
            this.GroupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.GroupBox GroupBox2;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.TextBox txtArray1;
        internal System.Windows.Forms.Button btnReverse;
        internal System.Windows.Forms.TextBox txtArray2;
        internal System.Windows.Forms.Button btnShiftLeft;
        internal System.Windows.Forms.TextBox txtArray3;
        internal System.Windows.Forms.Button btnShiftRight;
        internal System.Windows.Forms.TextBox txtArray4;
        internal System.Windows.Forms.Button btnRandomize;
        internal System.Windows.Forms.TextBox txtArray5;
        internal System.Windows.Forms.Button btnLoad;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Button btnSave;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.GroupBox GroupBox1;
        internal System.Windows.Forms.Label lblOperator;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.TextBox txtValue1;
        internal System.Windows.Forms.TextBox txtValue2;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.TextBox txtResultant;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Button btnAdd;
        internal System.Windows.Forms.Button btnSubtract;
        internal System.Windows.Forms.Button btnMultiply;
        internal System.Windows.Forms.Button btnDivide;
        internal System.Windows.Forms.Button btnModulus;
        internal System.Windows.Forms.Button btnPower;
    }
}

